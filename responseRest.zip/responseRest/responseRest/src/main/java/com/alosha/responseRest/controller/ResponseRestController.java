package com.alosha.responseRest.controller;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.alosha.responseRest.dao.entities.Student;
import com.alosha.responseRest.service.ResponseRestService;

@RestController
public class ResponseRestController {
	@Autowired
	ResponseRestService service;

	@PostMapping(value = "/students")
	public ResponseEntity<Student> saveStudent(@RequestBody Student student)
	{
		long regNo = student.getRegNo();
		Student persistedStudent =	service.retrieveStudent(regNo);
		HttpStatus status = HttpStatus.OK;
		if(persistedStudent!=null)
		{
			System.out.println("It is an update request");
			long persistedId = persistedStudent.getStudentId();
			student.setStudentId(persistedId);
			persistedStudent = service.saveStudent(student);
			status = HttpStatus.OK;
		}
		else
		{
			System.out.println("It is a create request");
			persistedStudent = service.saveStudent(student);
			status = HttpStatus.CREATED;
		}
		
		
		
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{regNo}").build(persistedStudent.getRegNo());
		HttpHeaders headers = new HttpHeaders();
		headers.setLocation(location);
		
		ResponseEntity<Student> responseEntity = new ResponseEntity<Student>(persistedStudent, headers, status);
		
		return responseEntity;
	}
	
	@GetMapping(value = "/students/{regNo}")
	public ResponseEntity<Student> retrieveStudent(@PathVariable("regNo") long registerationNo)
	{
		Student persistedStudent = service.retrieveStudent(registerationNo);
		
		return ResponseEntity.status(HttpStatus.OK).body(persistedStudent);
	}
	
	@DeleteMapping(value = "/students/{regNo}")
	public ResponseEntity<Void> deleteStudent(@PathVariable("regNo") long registerationNo)
	{
		service.deleteStudent(registerationNo);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
	}
}
