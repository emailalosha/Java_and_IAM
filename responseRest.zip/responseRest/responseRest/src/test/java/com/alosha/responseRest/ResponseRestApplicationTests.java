package com.alosha.responseRest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResponseRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
