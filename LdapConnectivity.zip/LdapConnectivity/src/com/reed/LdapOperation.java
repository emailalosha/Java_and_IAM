package com.reed;

import javax.naming.ldap.InitialLdapContext;

import com.reed.util.GetContext;

public class LdapOperation
{

	public static void main(String[] args)
	{
		InitialLdapContext context = GetContext.getContext();
		System.out.println(context);
	}
	
}
