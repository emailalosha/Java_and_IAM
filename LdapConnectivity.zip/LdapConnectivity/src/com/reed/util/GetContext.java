package com.reed.util;

import java.util.Hashtable;
import java.util.Properties;

import javax.naming.NamingException;
import javax.naming.ldap.InitialLdapContext;

import org.apache.log4j.Logger;

public class GetContext
{
	public static Logger logger = Logger.getLogger(com.reed.util.GetContext.class);
	static InitialLdapContext context;
	static Hashtable<String, String> environment = new Hashtable<String, String>();
	//These are of no use so commenting 
	/*
	 * static String PROVIDER_URL; static String SECURITY_PRINCIPAL; static String
	 * SECURITY_CREDENTIALS;
	 */

	static
	{
		Properties properties = LoadConfig.getProperties();

		environment.put(javax.naming.Context.PROVIDER_URL, properties.getProperty("PROVIDER_URL"));
		environment.put(javax.naming.Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		environment.put(javax.naming.Context.SECURITY_AUTHENTICATION, "simple");
		environment.put(javax.naming.Context.SECURITY_PRINCIPAL, properties.getProperty("SECURITY_PRINCIPAL"));
		environment.put(javax.naming.Context.SECURITY_CREDENTIALS, properties.getProperty("SECURITY_CREDENTIALS"));
		
		environment.put("com.sun.jndi.ldap.connect.timeout", "5000");
		environment.put("com.sun.jndi.ldap.read.timeout", "5000");

	}

	public static InitialLdapContext getContext()
	{

		try
		{
			context = new InitialLdapContext(environment, null);
		} catch (NamingException e)
		{
			logger.error("Error while creating context object " + e);
		}

		return context;
	}

	public static void closeContext(InitialLdapContext context)
	{

		try
		{
			if (context != null)
				context.close();
		} catch (NamingException e)
		{
			logger.error("Exception while closing the context " + e);
		}

	}

}
