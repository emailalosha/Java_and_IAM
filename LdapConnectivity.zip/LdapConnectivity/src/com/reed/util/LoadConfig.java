package com.reed.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;

public class LoadConfig
{

	public static Logger logger = Logger.getLogger(com.reed.util.LoadConfig.class);
	public static Properties properties;
	
	
	public static Properties getProperties()
	{
		
		String configFilePath = System.getProperty("config");
		FileInputStream fileInputStream = null;
		try
		{
			fileInputStream = new FileInputStream(configFilePath);
		}
		catch(FileNotFoundException exception)
		{
		logger.fatal("Config file not found, check VM arguement : "+exception);		
		}
		
		
		properties = new Properties();
		try
		{
			properties.load(fileInputStream);
		}
		catch(IOException exception)
		{
			logger.error("I/O Exception when loading property file : "+exception);		
		}
		
		return properties;
	}
	
}
