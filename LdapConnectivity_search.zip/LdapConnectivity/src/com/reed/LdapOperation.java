package com.reed;


import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;

import com.reed.util.GetContext;

public class LdapOperation
{

	public static void main(String[] args)
	{
		InitialLdapContext context = GetContext.getContext();
		
		
		SearchControls controls = new SearchControls();
		controls.setSearchScope(SearchControls.SUBTREE_SCOPE);
		
		String filter = "(uid=scarter)";
		
		String base = "dc=example,dc=com";
		
		try
		{
			NamingEnumeration<SearchResult> namingEnumeration = context.search(base, filter, controls);
			while(namingEnumeration.hasMoreElements())
			{
				SearchResult result = namingEnumeration.nextElement();
				Attributes allAttr = result.getAttributes();
				System.out.println(result.getNameInNamespace());
				NamingEnumeration<BasicAttribute> enumeration = (NamingEnumeration<BasicAttribute>) allAttr.getAll();
				while (enumeration.hasMoreElements())
				{
					BasicAttribute basicAttribute = (BasicAttribute) enumeration.nextElement();
					String nameValuePair[] = basicAttribute.toString().split(": ");
					
					if(nameValuePair[1].contains(", "))
					{
						String multiValue[] = nameValuePair[1].split(", ");
						for(String tmp : multiValue)
							System.out.println(nameValuePair[0]+" - "+tmp);
						
					}
					else
					{
						System.out.println(nameValuePair[0]+" - "+nameValuePair[1]);
					}
					
					
				}
				System.out.println();
			}
			
		}
		catch(NamingException exception)
		{
			exception.printStackTrace();
		}
		
	}
	
}
