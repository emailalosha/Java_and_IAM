package com.reed;


import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;

import com.reed.util.GetContext;

public class LdapOperation
{

	public static void main(String[] args)
	{
		InitialLdapContext context = GetContext.getContext();
		
		SearchControls controls = new SearchControls();
		controls.setSearchScope(SearchControls.SUBTREE_SCOPE);
		
		String filter = "(uid=scarter)";
		
		String base = "dc=example,dc=com";
		
		try
		{
			NamingEnumeration<SearchResult> namingEnumeration = context.search(base, filter, controls);
			while(namingEnumeration.hasMoreElements())
			{
				SearchResult result = namingEnumeration.nextElement();
				String DN = result.getNameInNamespace();
				
				// case 1 where we are adding value for attribute which is not defined currently 
				/*
				 * ModificationItem allAttr[] = new ModificationItem[1]; //ModificationItem
				 * descriptionAttr = new ModificationItem(DirContext.ADD_ATTRIBUTE, new
				 * BasicAttribute("description", "manual_description")); //ModificationItem
				 * descriptionAttr = new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new
				 * BasicAttribute("description", "manual_description_onceAgain"));
				 * ModificationItem descriptionAttr = new
				 * ModificationItem(DirContext.REMOVE_ATTRIBUTE, new
				 * BasicAttribute("description", "manual_description_onceAgain")); allAttr[0] =
				 * descriptionAttr;
				 * 
				 * context.modifyAttributes(DN, allAttr);
				 */
				
				// case 2 where we are adding value for attribute which is already defined and has value
				
				
				  ModificationItem allAttr[] = new ModificationItem[1];
				  ModificationItem cnItem = null;
				 
				  Attribute snAttr = result.getAttributes().get("displayName");
				  	 
				  
				  if(snAttr == null)
				  {
					  cnItem = new ModificationItem(DirContext.ADD_ATTRIBUTE, new BasicAttribute("displayName", "added_value"));
				  }
				  else
					  cnItem = new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new BasicAttribute("displayName", "replace_value")); 
				  
				  allAttr[0] = cnItem;
				  
				  context.modifyAttributes(DN, allAttr);
				  System.out.println("done");
				 
				
			}
			
		}
		catch(NamingException exception)
		{
			exception.printStackTrace();
		}
		
		GetContext.closeContext(context);
		
	}
	
}
