package com.reed;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;



public class SearchLdap
{
public static void main(String[] args) throws NamingException
{
	GetContext getContext = new GetContext();
	InitialLdapContext context = getContext.getContext();
	if(context != null)
	{
		SearchControls controls = new SearchControls();
		controls.setSearchScope(SearchControls.SUBTREE_SCOPE);
		
		NamingEnumeration<SearchResult> namingEnumeration = context.search("o=sso", "(uid=akumar)",controls);
		while (namingEnumeration.hasMoreElements())
		{
			SearchResult searchResult = (SearchResult) namingEnumeration.nextElement();
			System.out.println(searchResult.getNameInNamespace());
		}
	}
}
}
