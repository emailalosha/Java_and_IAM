package com.reed;

import java.util.Hashtable;
import java.util.Properties;

import javax.naming.NamingException;
import javax.naming.ldap.InitialLdapContext;

import org.apache.log4j.Logger;

public class GetContext
{
	public Logger logger = Logger.getLogger(GetContext.class);
	InitialLdapContext context;
	Hashtable<String, String> environment = new Hashtable<String, String>();

	public InitialLdapContext getContext()
	{
			//To set cert store and password
		 System.setProperty("javax.net.ssl.trustStore","C:/Users/Alok/Desktop/certs/cacerts.p12");
		 System.setProperty("javax.net.ssl.trustStorePassword", "changeit");
		 
		environment.put(javax.naming.Context.PROVIDER_URL, "ldaps://iam.reed.com:1636");
		environment.put(javax.naming.Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		environment.put(javax.naming.Context.SECURITY_AUTHENTICATION, "simple");
		environment.put(javax.naming.Context.SECURITY_PRINCIPAL, "cn=Directory Manager");
		environment.put(javax.naming.Context.SECURITY_CREDENTIALS, "Jaiho211.");
		//To enable SSL connection
		environment.put(javax.naming.Context.SECURITY_PROTOCOL, "ssl");
		//environment.put("com.sun.jndi.ldap.connect.timeout", "5000");
		//environment.put("com.sun.jndi.ldap.read.timeout", "5000");
		try
		{
		context = new InitialLdapContext(environment, null);
		} catch (NamingException e)
		{
			logger.error("Error while creating context object " + e);
			System.out.println("Error while creating context object " + e);
		}
		return context;
	}
	public void closeContext(InitialLdapContext context)
	{
		try
		{
			if (context != null)
				context.close();
		} catch (NamingException e)
		{
			logger.error("Exception while closing the context " + e);
		}
	}

}
