package com.reed;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;

import com.reed.util.GetContext;

public class LdapOperation
{

	public static void main(String[] args)
	{
		InitialLdapContext context = GetContext.getContext();

		SearchControls controls = new SearchControls();
		controls.setSearchScope(SearchControls.SUBTREE_SCOPE);

		//This search will change based on entry on which you act upon in your directory server
		String filter = "(uid=scarter)";

		String base = "dc=example,dc=com";

		try
		{
			NamingEnumeration<SearchResult> namingEnumeration = context.search(base, filter, controls);
			while (namingEnumeration.hasMoreElements())
			{

				SearchResult result = namingEnumeration.nextElement();
				String DN = result.getNameInNamespace();

				/*
				 * case - 1 you can't add same value onceagain, it will throw LDAP error 20
				 * (value already present)
				 * We cannot add a new value for mail with same value
				 *  ModificationItem mailAttr1 = new ModificationItem(DirContext.ADD_ATTRIBUTE,
				  new BasicAttribute("mail", "manual@abc.com"));
				 */
				
				  ModificationItem item[] = new ModificationItem[2]; ModificationItem mailAttr
				  = new ModificationItem(DirContext.ADD_ATTRIBUTE, new
				  BasicAttribute("mail","manual@abc.com"));
				
				  ModificationItem mailAttr1 = new ModificationItem(DirContext.ADD_ATTRIBUTE,
				  new BasicAttribute("mail","manual_1@abc.com"));
				  
				  item[0] = mailAttr; item[1] = mailAttr1; context.modifyAttributes(DN, item);
				 

				// case - 2 -- comment case 1 and then execute this case. Replace attribute
				// replaces all the values for mail and replaces with only one value

				/*
				 * ModificationItem item[] = new ModificationItem[1]; ModificationItem mailAttr
				 * = new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new
				 * BasicAttribute("mail","manual_1@abc.com"));
				 * 
				 * item[0] = mailAttr; context.modifyAttributes(DN, item);
				 */
				 

				/*
				 * case - 3 -- comment case 1 and 2 and then execute this case. In order to
				 * replace certian value of multi-valued attribute with new value first remove
				 * the exact value and then add new value like below
				 */

				/*
				 * ModificationItem item[] = new ModificationItem[2]; ModificationItem
				 * mailAttr_remove = new ModificationItem(DirContext.REMOVE_ATTRIBUTE, new
				 * BasicAttribute("mail","manual_1@abc.com")); ModificationItem mailAttr_add =
				 * new ModificationItem(DirContext.ADD_ATTRIBUTE, new
				 * BasicAttribute("mail","manual_added_new@abc.com"));
				 * 
				 * item[0] = mailAttr_remove; item[1] = mailAttr_add;
				 * context.modifyAttributes(DN, item);
				 */
				 

			}

		} catch (NamingException exception)
		{
			exception.printStackTrace();
		}

		System.out.println("done");

	}

}
